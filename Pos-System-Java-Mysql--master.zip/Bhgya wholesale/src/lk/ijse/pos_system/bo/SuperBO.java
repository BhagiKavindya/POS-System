package lk.ijse.pos_system.bo;

public interface SuperBO {
}
