package lk.ijse.pos_system.dao;

public interface SuperDAO {
}
