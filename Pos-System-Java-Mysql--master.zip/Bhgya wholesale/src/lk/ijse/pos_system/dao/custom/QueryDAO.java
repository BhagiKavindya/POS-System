package lk.ijse.pos_system.dao.custom;

import lk.ijse.pos_system.dao.SuperDAO;

public interface QueryDAO extends SuperDAO {

}
