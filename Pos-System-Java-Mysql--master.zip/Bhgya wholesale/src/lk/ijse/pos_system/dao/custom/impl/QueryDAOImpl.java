package lk.ijse.pos_system.dao.custom.impl;

import lk.ijse.pos_system.dao.custom.QueryDAO;

public class QueryDAOImpl implements QueryDAO {
}
